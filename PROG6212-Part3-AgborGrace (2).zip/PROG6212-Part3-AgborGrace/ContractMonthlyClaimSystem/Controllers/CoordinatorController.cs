﻿// Controllers/CoordinatorController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ContractMonthlyClaimSystem.Data;
using ContractMonthlyClaimSystem.Models;
using ContractMonthlyClaimSystem.Models.ViewModels;
using ContractMonthlyClaimSystem.Helpers;
using ContractMonthlyClaimSystem.Filters;

namespace ContractMonthlyClaimSystem.Controllers
{
    [AuthorizeSession("Coordinator")]
    public class CoordinatorController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CoordinatorController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var userName = SessionHelper.GetUserName(HttpContext.Session);
            ViewBag.UserName = userName;

            var stats = new
            {
                PendingReview = await _context.Claims.CountAsync(c => c.Status == "Pending"),
                ReviewedToday = await _context.Claims.CountAsync(c =>
                    c.CoordinatorReviewDate.HasValue &&
                    c.CoordinatorReviewDate.Value.Date == DateTime.Today),
                TotalReviewed = await _context.Claims.CountAsync(c => c.CoordinatorReviewDate.HasValue),
                AwaitingManager = await _context.Claims.CountAsync(c => c.Status == "CoordinatorApproved")
            };

            ViewBag.Stats = stats;
            return View();
        }

        public async Task<IActionResult> ReviewClaims(string? status = "Pending")
        {
            var query = _context.Claims
                .Include(c => c.Lecturer)
                .Include(c => c.Documents)
                .AsQueryable();

            if (status == "Pending")
            {
                query = query.Where(c => c.Status == "Pending");
            }
            else if (status == "Reviewed")
            {
                query = query.Where(c => c.CoordinatorReviewDate.HasValue);
            }
            else if (status == "All")
            {
                // Show all claims
            }

            var claims = await query.OrderByDescending(c => c.SubmittedDate).ToListAsync();

            ViewBag.CurrentFilter = status;
            return View(claims);
        }

        [HttpGet]
        public async Task<IActionResult> ReviewClaimDetail(int id)
        {
            var claim = await _context.Claims
                .Include(c => c.Lecturer)
                .Include(c => c.Documents)
                .FirstOrDefaultAsync(c => c.ClaimId == id);

            if (claim == null)
            {
                return NotFound();
            }

            var model = new ClaimReviewViewModel
            {
                ClaimId = claim.ClaimId,
                LecturerName = $"{claim.Lecturer.FirstName} {claim.Lecturer.LastName}",
                HoursWorked = claim.HoursWorked,
                HourlyRate = claim.HourlyRate,
                TotalAmount = claim.TotalAmount,
                ClaimMonth = claim.ClaimMonth,
                Status = claim.Status,
                SubmittedDate = claim.SubmittedDate,
                Documents = claim.Documents.ToList(),
                CoordinatorComments = claim.CoordinatorComments,
                ManagerComments = claim.ManagerComments
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveClaim(int id, string comments)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null)
            {
                return NotFound();
            }

            if (claim.Status != "Pending")
            {
                TempData["ErrorMessage"] = "This claim has already been reviewed";
                return RedirectToAction("ReviewClaims");
            }

            claim.Status = "CoordinatorApproved";
            claim.CoordinatorReviewDate = DateTime.Now;
            claim.CoordinatorComments = comments;

            _context.Claims.Update(claim);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Claim approved and forwarded to Academic Manager";
            return RedirectToAction("ReviewClaims");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RejectClaim(int id, string comments)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null)
            {
                return NotFound();
            }

            if (claim.Status != "Pending")
            {
                TempData["ErrorMessage"] = "This claim has already been reviewed";
                return RedirectToAction("ReviewClaims");
            }

            if (string.IsNullOrWhiteSpace(comments))
            {
                TempData["ErrorMessage"] = "Rejection reason is required";
                return RedirectToAction("ReviewClaimDetail", new { id });
            }

            claim.Status = "Rejected";
            claim.CoordinatorReviewDate = DateTime.Now;
            claim.CoordinatorComments = comments;

            _context.Claims.Update(claim);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Claim rejected";
            return RedirectToAction("ReviewClaims");
        }

        public async Task<IActionResult> ViewDocument(int id)
        {
            var document = await _context.ClaimDocuments.FindAsync(id);
            if (document == null)
            {
                return NotFound();
            }

            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", document.FilePath.TrimStart('/'));
            if (!System.IO.File.Exists(filePath))
            {
                return NotFound();
            }

            var fileBytes = await System.IO.File.ReadAllBytesAsync(filePath);
            var contentType = "application/octet-stream";

            var extension = Path.GetExtension(document.FileName).ToLower();
            contentType = extension switch
            {
                ".pdf" => "application/pdf",
                ".jpg" or ".jpeg" => "image/jpeg",
                ".png" => "image/png",
                ".doc" => "application/msword",
                ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                _ => "application/octet-stream"
            };

            return File(fileBytes, contentType, document.FileName);
        }
    }
}
