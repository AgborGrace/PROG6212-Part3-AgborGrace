﻿// Controllers/HRController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ContractMonthlyClaimSystem.Data;
using ContractMonthlyClaimSystem.Models;
using ContractMonthlyClaimSystem.Models.ViewModels;
using ContractMonthlyClaimSystem.Helpers;
using ContractMonthlyClaimSystem.Filters;

namespace ContractMonthlyClaimSystem.Controllers
{
    [AuthorizeSession("HR")]
    public class HRController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HRController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var userName = SessionHelper.GetUserName(HttpContext.Session);
            ViewBag.UserName = userName;

            var stats = new
            {
                TotalUsers = _context.Users.Count(u => u.IsActive),
                TotalClaims = _context.Claims.Count(),
                PendingClaims = _context.Claims.Count(c => c.Status == "Pending"),
                TotalAmount = _context.Claims.Sum(c => (decimal?)c.TotalAmount) ?? 0
            };

            ViewBag.Stats = stats;
            return View();
        }

        // User Management
        [HttpGet]
        public IActionResult ManageUsers()
        {
            var users = _context.Users.OrderByDescending(u => u.CreatedDate).ToList();
            return View(users);
        }

        [HttpGet]
        public IActionResult CreateUser()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateUser(CreateUserViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Check if email already exists
            if (await _context.Users.AnyAsync(u => u.Email == model.Email))
            {
                ModelState.AddModelError("Email", "Email already exists");
                return View(model);
            }

            // Validate hourly rate for lecturers
            if (model.Role == "Lecturer" && (!model.HourlyRate.HasValue || model.HourlyRate <= 0))
            {
                ModelState.AddModelError("HourlyRate", "Hourly rate is required for lecturers");
                return View(model);
            }

            var user = new User
            {
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                PasswordHash = PasswordHasher.HashPassword(model.Password),
                Role = model.Role,
                HourlyRate = model.Role == "Lecturer" ? model.HourlyRate : null,
                CreatedDate = DateTime.Now,
                IsActive = true
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"User {user.FirstName} {user.LastName} created successfully. Login credentials sent to {user.Email}.";
            return RedirectToAction("ManageUsers");
        }

        [HttpGet]
        public async Task<IActionResult> EditUser(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            var model = new EditUserViewModel
            {
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                Role = user.Role,
                HourlyRate = user.HourlyRate,
                IsActive = user.IsActive
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditUser(EditUserViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var user = await _context.Users.FindAsync(model.UserId);
            if (user == null)
            {
                return NotFound();
            }

            // Check email uniqueness
            if (await _context.Users.AnyAsync(u => u.Email == model.Email && u.UserId != model.UserId))
            {
                ModelState.AddModelError("Email", "Email already exists");
                return View(model);
            }

            user.FirstName = model.FirstName;
            user.LastName = model.LastName;
            user.Email = model.Email;
            user.Role = model.Role;
            user.HourlyRate = model.Role == "Lecturer" ? model.HourlyRate : null;
            user.IsActive = model.IsActive;

            if (!string.IsNullOrEmpty(model.NewPassword))
            {
                user.PasswordHash = PasswordHasher.HashPassword(model.NewPassword);
            }

            _context.Users.Update(user);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "User updated successfully";
            return RedirectToAction("ManageUsers");
        }

        [HttpPost]
        public async Task<IActionResult> DeactivateUser(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            user.IsActive = false;
            _context.Users.Update(user);
            await _context.SaveChangesAsync();

            return Json(new { success = true, message = "User deactivated successfully" });
        }

        // Report Generation
        [HttpGet]
        public IActionResult GenerateReport()
        {
            var model = new ReportViewModel
            {
                StartDate = DateTime.Now.AddMonths(-1),
                EndDate = DateTime.Now,
                Lecturers = _context.Users.Where(u => u.Role == "Lecturer" && u.IsActive).ToList(),
                Claims = new List<Claim>()
            };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> GenerateReport(ReportViewModel model)
        {
            var query = _context.Claims
                .Include(c => c.Lecturer)
                .Include(c => c.Documents)
                .AsQueryable();

            if (model.StartDate.HasValue)
            {
                query = query.Where(c => c.SubmittedDate >= model.StartDate.Value);
            }

            if (model.EndDate.HasValue)
            {
                query = query.Where(c => c.SubmittedDate <= model.EndDate.Value);
            }

            if (!string.IsNullOrEmpty(model.Status))
            {
                query = query.Where(c => c.Status == model.Status);
            }

            if (model.LecturerId.HasValue)
            {
                query = query.Where(c => c.LecturerId == model.LecturerId.Value);
            }

            model.Claims = await query.OrderByDescending(c => c.SubmittedDate).ToListAsync();
            model.Lecturers = await _context.Users.Where(u => u.Role == "Lecturer" && u.IsActive).ToListAsync();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> DownloadReportPdf(DateTime? startDate, DateTime? endDate, string? status, int? lecturerId)
        {
            var query = _context.Claims
                .Include(c => c.Lecturer)
                .AsQueryable();

            if (startDate.HasValue)
                query = query.Where(c => c.SubmittedDate >= startDate.Value);

            if (endDate.HasValue)
                query = query.Where(c => c.SubmittedDate <= endDate.Value);

            if (!string.IsNullOrEmpty(status))
                query = query.Where(c => c.Status == status);

            if (lecturerId.HasValue)
                query = query.Where(c => c.LecturerId == lecturerId.Value);

            var claims = await query.ToListAsync();

            var reportTitle = $"Claims Report - {DateTime.Now:dd/MM/yyyy}";
            var pdfBytes = PdfGenerator.GenerateClaimReport(claims, reportTitle);

            return File(pdfBytes, "application/pdf", $"ClaimsReport_{DateTime.Now:yyyyMMdd}.pdf");
        }
    }
}
