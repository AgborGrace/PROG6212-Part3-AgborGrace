﻿// Controllers/LecturerController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ContractMonthlyClaimSystem.Data;
using ContractMonthlyClaimSystem.Models;
using ContractMonthlyClaimSystem.Models.ViewModels;
using ContractMonthlyClaimSystem.Helpers;
using ContractMonthlyClaimSystem.Filters;

namespace ContractMonthlyClaimSystem.Controllers
{
    [AuthorizeSession("Lecturer")]
    public class LecturerController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public LecturerController(ApplicationDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public async Task<IActionResult> Index()
        {
            var userId = SessionHelper.GetUserId(HttpContext.Session);
            var userName = SessionHelper.GetUserName(HttpContext.Session);

            ViewBag.UserName = userName;

            var stats = new
            {
                TotalClaims = await _context.Claims.CountAsync(c => c.LecturerId == userId),
                PendingClaims = await _context.Claims.CountAsync(c => c.LecturerId == userId && c.Status == "Pending"),
                ApprovedClaims = await _context.Claims.CountAsync(c => c.LecturerId == userId && c.Status == "Approved"),
                TotalEarnings = await _context.Claims
                    .Where(c => c.LecturerId == userId && c.Status == "Approved")
                    .SumAsync(c => (decimal?)c.TotalAmount) ?? 0
            };

            ViewBag.Stats = stats;
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> SubmitClaim()
        {
            var userId = SessionHelper.GetUserId(HttpContext.Session);
            var user = await _context.Users.FindAsync(userId);

            var model = new SubmitClaimViewModel
            {
                LecturerName = $"{user.FirstName} {user.LastName}",
                HourlyRate = user.HourlyRate ?? 0
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SubmitClaim(SubmitClaimViewModel model)
        {
            var userId = SessionHelper.GetUserId(HttpContext.Session);
            var user = await _context.Users.FindAsync(userId);

            // Re-populate model data for display
            model.LecturerName = $"{user.FirstName} {user.LastName}";
            model.HourlyRate = user.HourlyRate ?? 0;

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Validate maximum hours (180 per month)
            if (model.HoursWorked > 180)
            {
                ModelState.AddModelError("HoursWorked", "Hours worked cannot exceed 180 hours per month");
                return View(model);
            }

            // Check if claim already exists for this month
            var existingClaim = await _context.Claims
                .FirstOrDefaultAsync(c => c.LecturerId == userId && c.ClaimMonth == model.ClaimMonth);

            if (existingClaim != null)
            {
                ModelState.AddModelError("ClaimMonth", "You have already submitted a claim for this month");
                return View(model);
            }

            // Calculate total
            var totalAmount = model.HoursWorked * model.HourlyRate;

            // Create claim
            var claim = new Claim
            {
                LecturerId = userId.Value,
                HoursWorked = model.HoursWorked,
                HourlyRate = model.HourlyRate,
                TotalAmount = totalAmount,
                ClaimMonth = model.ClaimMonth,
                Status = "Pending",
                SubmittedDate = DateTime.Now
            };

            _context.Claims.Add(claim);
            await _context.SaveChangesAsync();

            // Upload documents
            if (model.Documents != null && model.Documents.Any())
            {
                var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                foreach (var file in model.Documents)
                {
                    if (file.Length > 0)
                    {
                        var fileName = $"{claim.ClaimId}_{Guid.NewGuid()}_{Path.GetFileName(file.FileName)}";
                        var filePath = Path.Combine(uploadsFolder, fileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await file.CopyToAsync(stream);
                        }

                        var document = new ClaimDocument
                        {
                            ClaimId = claim.ClaimId,
                            FileName = file.FileName,
                            FilePath = $"/uploads/{fileName}",
                            UploadedDate = DateTime.Now
                        };

                        _context.ClaimDocuments.Add(document);
                    }
                }

                await _context.SaveChangesAsync();
            }

            TempData["SuccessMessage"] = "Claim submitted successfully";
            return RedirectToAction("MyClaims");
        }

        public async Task<IActionResult> MyClaims()
        {
            var userId = SessionHelper.GetUserId(HttpContext.Session);
            var claims = await _context.Claims
                .Include(c => c.Documents)
                .Where(c => c.LecturerId == userId)
                .OrderByDescending(c => c.SubmittedDate)
                .ToListAsync();

            return View(claims);
        }

        public async Task<IActionResult> ViewClaim(int id)
        {
            var userId = SessionHelper.GetUserId(HttpContext.Session);
            var claim = await _context.Claims
                .Include(c => c.Documents)
                .Include(c => c.Lecturer)
                .FirstOrDefaultAsync(c => c.ClaimId == id && c.LecturerId == userId);

            if (claim == null)
            {
                return NotFound();
            }

            return View(claim);
        }
    }
}