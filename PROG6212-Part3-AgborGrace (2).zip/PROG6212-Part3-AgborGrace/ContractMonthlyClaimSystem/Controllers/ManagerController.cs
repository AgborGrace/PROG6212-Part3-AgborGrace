﻿// Controllers/ManagerController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ContractMonthlyClaimSystem.Data;
using ContractMonthlyClaimSystem.Models;
using ContractMonthlyClaimSystem.Models.ViewModels;
using ContractMonthlyClaimSystem.Helpers;
using ContractMonthlyClaimSystem.Filters;

namespace ContractMonthlyClaimSystem.Controllers
{
    [AuthorizeSession("Manager")]
    public class ManagerController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ManagerController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var userName = SessionHelper.GetUserName(HttpContext.Session);
            ViewBag.UserName = userName;

            var stats = new
            {
                PendingApproval = await _context.Claims.CountAsync(c => c.Status == "CoordinatorApproved"),
                ApprovedToday = await _context.Claims.CountAsync(c =>
                    c.ManagerReviewDate.HasValue &&
                    c.ManagerReviewDate.Value.Date == DateTime.Today),
                TotalApproved = await _context.Claims.CountAsync(c => c.Status == "Approved"),
                TotalAmount = await _context.Claims
                    .Where(c => c.Status == "Approved")
                    .SumAsync(c => (decimal?)c.TotalAmount) ?? 0
            };

            ViewBag.Stats = stats;
            return View();
        }

        public async Task<IActionResult> ApproveClaims(string? status = "CoordinatorApproved")
        {
            var query = _context.Claims
                .Include(c => c.Lecturer)
                .Include(c => c.Documents)
                .AsQueryable();

            if (status == "CoordinatorApproved")
            {
                query = query.Where(c => c.Status == "CoordinatorApproved");
            }
            else if (status == "Approved")
            {
                query = query.Where(c => c.Status == "Approved");
            }
            else if (status == "Rejected")
            {
                query = query.Where(c => c.Status == "Rejected");
            }
            else if (status == "All")
            {
                query = query.Where(c => c.ManagerReviewDate.HasValue);
            }

            var claims = await query.OrderByDescending(c => c.SubmittedDate).ToListAsync();

            ViewBag.CurrentFilter = status;
            return View(claims);
        }

        [HttpGet]
        public async Task<IActionResult> ApproveClaimDetail(int id)
        {
            var claim = await _context.Claims
                .Include(c => c.Lecturer)
                .Include(c => c.Documents)
                .FirstOrDefaultAsync(c => c.ClaimId == id);

            if (claim == null)
            {
                return NotFound();
            }

            var model = new ClaimReviewViewModel
            {
                ClaimId = claim.ClaimId,
                LecturerName = $"{claim.Lecturer.FirstName} {claim.Lecturer.LastName}",
                HoursWorked = claim.HoursWorked,
                HourlyRate = claim.HourlyRate,
                TotalAmount = claim.TotalAmount,
                ClaimMonth = claim.ClaimMonth,
                Status = claim.Status,
                SubmittedDate = claim.SubmittedDate,
                Documents = claim.Documents.ToList(),
                CoordinatorComments = claim.CoordinatorComments,
                ManagerComments = claim.ManagerComments
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> FinalApproveClaim(int id, string comments)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null)
            {
                return NotFound();
            }

            if (claim.Status != "CoordinatorApproved")
            {
                TempData["ErrorMessage"] = "This claim is not ready for final approval";
                return RedirectToAction("ApproveClaims");
            }

            claim.Status = "Approved";
            claim.ManagerReviewDate = DateTime.Now;
            claim.ManagerComments = comments;

            _context.Claims.Update(claim);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Claim approved successfully. Payment can be processed.";
            return RedirectToAction("ApproveClaims");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> FinalRejectClaim(int id, string comments)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null)
            {
                return NotFound();
            }

            if (claim.Status != "CoordinatorApproved")
            {
                TempData["ErrorMessage"] = "This claim is not ready for review";
                return RedirectToAction("ApproveClaims");
            }

            if (string.IsNullOrWhiteSpace(comments))
            {
                TempData["ErrorMessage"] = "Rejection reason is required";
                return RedirectToAction("ApproveClaimDetail", new { id });
            }

            claim.Status = "Rejected";
            claim.ManagerReviewDate = DateTime.Now;
            claim.ManagerComments = comments;

            _context.Claims.Update(claim);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Claim rejected";
            return RedirectToAction("ApproveClaims");
        }

        public async Task<IActionResult> ViewDocument(int id)
        {
            var document = await _context.ClaimDocuments.FindAsync(id);
            if (document == null)
            {
                return NotFound();
            }

            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", document.FilePath.TrimStart('/'));
            if (!System.IO.File.Exists(filePath))
            {
                return NotFound();
            }

            var fileBytes = await System.IO.File.ReadAllBytesAsync(filePath);
            var contentType = "application/octet-stream";

            var extension = Path.GetExtension(document.FileName).ToLower();
            contentType = extension switch
            {
                ".pdf" => "application/pdf",
                ".jpg" or ".jpeg" => "image/jpeg",
                ".png" => "image/png",
                ".doc" => "application/msword",
                ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                _ => "application/octet-stream"
            };

            return File(fileBytes, contentType, document.FileName);
        }

        public async Task<IActionResult> ClaimHistory()
        {
            var claims = await _context.Claims
                .Include(c => c.Lecturer)
                .Where(c => c.ManagerReviewDate.HasValue)
                .OrderByDescending(c => c.ManagerReviewDate)
                .ToListAsync();

            return View(claims);
        }
    }
}
