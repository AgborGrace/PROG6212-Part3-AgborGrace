﻿// Data/ApplicationDbContext.cs
using Microsoft.EntityFrameworkCore;
using ContractMonthlyClaimSystem.Models;

namespace ContractMonthlyClaimSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Claim> Claims { get; set; }
        public DbSet<ClaimDocument> ClaimDocuments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure User entity
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.UserId);
                entity.HasIndex(e => e.Email).IsUnique();
                entity.Property(e => e.CreatedDate).HasDefaultValueSql("GETDATE()");
                entity.Property(e => e.IsActive).HasDefaultValue(true);
            });

            // Configure Claim entity
            modelBuilder.Entity<Claim>(entity =>
            {
                entity.HasKey(e => e.ClaimId);
                entity.Property(e => e.Status).HasDefaultValue("Pending");
                entity.Property(e => e.SubmittedDate).HasDefaultValueSql("GETDATE()");

                entity.HasOne(e => e.Lecturer)
                    .WithMany(u => u.Claims)
                    .HasForeignKey(e => e.LecturerId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Configure ClaimDocument entity
            modelBuilder.Entity<ClaimDocument>(entity =>
            {
                entity.HasKey(e => e.DocumentId);
                entity.Property(e => e.UploadedDate).HasDefaultValueSql("GETDATE()");

                entity.HasOne(e => e.Claim)
                    .WithMany(c => c.Documents)
                    .HasForeignKey(e => e.ClaimId)
                    .OnDelete(DeleteBehavior.Cascade);
            });
        }
    }
}
