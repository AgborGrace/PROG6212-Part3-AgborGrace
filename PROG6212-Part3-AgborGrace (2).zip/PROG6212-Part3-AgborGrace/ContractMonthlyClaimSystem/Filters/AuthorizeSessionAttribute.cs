﻿// Filters/AuthorizeSessionAttribute.cs
using ContractMonthlyClaimSystem.Data;
using ContractMonthlyClaimSystem.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;

namespace ContractMonthlyClaimSystem.Filters
{
    public class AuthorizeSessionAttribute : ActionFilterAttribute
    {
        private readonly string[] _allowedRoles;

        public AuthorizeSessionAttribute(params string[] allowedRoles)
        {
            _allowedRoles = allowedRoles;
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var session = context.HttpContext.Session;

            if (!SessionHelper.IsAuthenticated(session))
            {
                context.Result = new RedirectToActionResult("Login", "Account", null);
                return;
            }

            if (_allowedRoles != null && _allowedRoles.Length > 0)
            {
                var userRole = SessionHelper.GetUserRole(session);
                if (!_allowedRoles.Contains(userRole))
                {
                    context.Result = new RedirectToActionResult("AccessDenied", "Account", null);
                    return;
                }
            }

            base.OnActionExecuting(context);
        }
    }
}

