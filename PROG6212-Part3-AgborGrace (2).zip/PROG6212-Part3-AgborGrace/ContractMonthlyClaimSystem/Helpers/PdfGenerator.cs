﻿// Helpers/PdfGenerator.cs
using iTextSharp.text;
using iTextSharp.text.pdf;
using ContractMonthlyClaimSystem.Models;

namespace ContractMonthlyClaimSystem.Helpers
{
    public class PdfGenerator
    {
        public static byte[] GenerateClaimReport(List<Claim> claims, string reportTitle)
        {
            using (var ms = new MemoryStream())
            {
                // Create document
                Document document = new Document(PageSize.A4, 25, 25, 30, 30);
                PdfWriter writer = PdfWriter.GetInstance(document, ms);
                document.Open();

                // Title
                Font titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK);
                Paragraph title = new Paragraph(reportTitle, titleFont);
                title.Alignment = Element.ALIGN_CENTER;
                document.Add(title);

                // Generation date
                Font dateFont = FontFactory.GetFont(FontFactory.HELVETICA, 10, BaseColor.GRAY);
                Paragraph date = new Paragraph($"Generated: {DateTime.Now:dd/MM/yyyy HH:mm}", dateFont);
                date.Alignment = Element.ALIGN_CENTER;
                document.Add(date);

                // Add space
                document.Add(new Paragraph("\n"));

                // Summary statistics
                var totalClaims = claims.Count;
                var totalAmount = claims.Sum(c => c.TotalAmount);
                var pendingClaims = claims.Count(c => c.Status == "Pending");
                var approvedClaims = claims.Count(c => c.Status == "Approved");

                Font summaryFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 12, BaseColor.BLACK);
                document.Add(new Paragraph($"Total Claims: {totalClaims}", summaryFont));
                document.Add(new Paragraph($"Total Amount: R{totalAmount:N2}"));
                document.Add(new Paragraph($"Pending: {pendingClaims} | Approved: {approvedClaims}"));
                document.Add(new Paragraph("\n"));

                // Create table
                PdfPTable table = new PdfPTable(6);
                table.WidthPercentage = 100;
                table.SetWidths(new float[] { 3, 2, 2, 2, 2, 2 });

                // Add headers
                Font headerFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 10, BaseColor.WHITE);

                PdfPCell header1 = new PdfPCell(new Phrase("Lecturer", headerFont));
                header1.BackgroundColor = BaseColor.GRAY;
                header1.HorizontalAlignment = Element.ALIGN_CENTER;
                header1.Padding = 5;
                table.AddCell(header1);

                PdfPCell header2 = new PdfPCell(new Phrase("Month", headerFont));
                header2.BackgroundColor = BaseColor.GRAY;
                header2.HorizontalAlignment = Element.ALIGN_CENTER;
                header2.Padding = 5;
                table.AddCell(header2);

                PdfPCell header3 = new PdfPCell(new Phrase("Hours", headerFont));
                header3.BackgroundColor = BaseColor.GRAY;
                header3.HorizontalAlignment = Element.ALIGN_CENTER;
                header3.Padding = 5;
                table.AddCell(header3);

                PdfPCell header4 = new PdfPCell(new Phrase("Rate", headerFont));
                header4.BackgroundColor = BaseColor.GRAY;
                header4.HorizontalAlignment = Element.ALIGN_CENTER;
                header4.Padding = 5;
                table.AddCell(header4);

                PdfPCell header5 = new PdfPCell(new Phrase("Amount", headerFont));
                header5.BackgroundColor = BaseColor.GRAY;
                header5.HorizontalAlignment = Element.ALIGN_CENTER;
                header5.Padding = 5;
                table.AddCell(header5);

                PdfPCell header6 = new PdfPCell(new Phrase("Status", headerFont));
                header6.BackgroundColor = BaseColor.GRAY;
                header6.HorizontalAlignment = Element.ALIGN_CENTER;
                header6.Padding = 5;
                table.AddCell(header6);

                // Add data rows
                Font dataFont = FontFactory.GetFont(FontFactory.HELVETICA, 9, BaseColor.BLACK);

                foreach (var claim in claims.OrderByDescending(c => c.SubmittedDate))
                {
                    PdfPCell cell1 = new PdfPCell(new Phrase($"{claim.Lecturer.FirstName} {claim.Lecturer.LastName}", dataFont));
                    cell1.Padding = 5;
                    table.AddCell(cell1);

                    PdfPCell cell2 = new PdfPCell(new Phrase(claim.ClaimMonth, dataFont));
                    cell2.Padding = 5;
                    table.AddCell(cell2);

                    PdfPCell cell3 = new PdfPCell(new Phrase(claim.HoursWorked.ToString("N2"), dataFont));
                    cell3.Padding = 5;
                    table.AddCell(cell3);

                    PdfPCell cell4 = new PdfPCell(new Phrase($"R{claim.HourlyRate:N2}", dataFont));
                    cell4.Padding = 5;
                    table.AddCell(cell4);

                    PdfPCell cell5 = new PdfPCell(new Phrase($"R{claim.TotalAmount:N2}", dataFont));
                    cell5.Padding = 5;
                    table.AddCell(cell5);

                    PdfPCell cell6 = new PdfPCell(new Phrase(claim.Status, dataFont));
                    cell6.Padding = 5;
                    table.AddCell(cell6);
                }

                document.Add(table);

                // Add footer
                document.Add(new Paragraph("\n"));
                Font footerFont = FontFactory.GetFont(FontFactory.HELVETICA, 8, BaseColor.GRAY);
                Paragraph footer = new Paragraph("Contract Monthly Claim System - Confidential", footerFont);
                footer.Alignment = Element.ALIGN_CENTER;
                document.Add(footer);

                document.Close();
                writer.Close();

                return ms.ToArray();
            }
        }
    }
}