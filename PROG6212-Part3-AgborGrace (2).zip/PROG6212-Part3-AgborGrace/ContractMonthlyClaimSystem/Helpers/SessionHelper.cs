﻿// Helpers/SessionHelper.cs
using Microsoft.AspNetCore.Http;
using System.Text.Json;

namespace ContractMonthlyClaimSystem.Helpers
{
    public static class SessionHelper
    {
        private const string UserIdKey = "UserId";
        private const string UserEmailKey = "UserEmail";
        private const string UserRoleKey = "UserRole";
        private const string UserNameKey = "UserName";

        public static void SetUserSession(ISession session, int userId, string email, string role, string name)
        {
            session.SetInt32(UserIdKey, userId);
            session.SetString(UserEmailKey, email);
            session.SetString(UserRoleKey, role);
            session.SetString(UserNameKey, name);
        }

        public static int? GetUserId(ISession session)
        {
            return session.GetInt32(UserIdKey);
        }

        public static string? GetUserEmail(ISession session)
        {
            return session.GetString(UserEmailKey);
        }

        public static string? GetUserRole(ISession session)
        {
            return session.GetString(UserRoleKey);
        }

        public static string? GetUserName(ISession session)
        {
            return session.GetString(UserNameKey);
        }

        public static bool IsAuthenticated(ISession session)
        {
            return session.GetInt32(UserIdKey).HasValue;
        }

        public static void ClearSession(ISession session)
        {
            session.Clear();
        }
    }
}