﻿// Models/Claim.cs
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ContractMonthlyClaimSystem.Models
{
    public class Claim
    {
        [Key]
        public int ClaimId { get; set; }

        [Required]
        public int LecturerId { get; set; }

        [Required]
        [Range(0.01, 180, ErrorMessage = "Hours worked must be between 0.01 and 180")]
        public decimal HoursWorked { get; set; }

        [Required]
        public decimal HourlyRate { get; set; }

        [Required]
        public decimal TotalAmount { get; set; }

        [Required]
        [StringLength(20)]
        public string ClaimMonth { get; set; }

        [StringLength(50)]
        public string Status { get; set; } = "Pending"; // Pending, CoordinatorApproved, Approved, Rejected

        public DateTime SubmittedDate { get; set; } = DateTime.Now;

        public DateTime? CoordinatorReviewDate { get; set; }

        public DateTime? ManagerReviewDate { get; set; }

        [StringLength(500)]
        public string? CoordinatorComments { get; set; }

        [StringLength(500)]
        public string? ManagerComments { get; set; }

        // Navigation properties
        [ForeignKey("LecturerId")]
        public virtual User Lecturer { get; set; }

        public virtual ICollection<ClaimDocument> Documents { get; set; }
    }
}

