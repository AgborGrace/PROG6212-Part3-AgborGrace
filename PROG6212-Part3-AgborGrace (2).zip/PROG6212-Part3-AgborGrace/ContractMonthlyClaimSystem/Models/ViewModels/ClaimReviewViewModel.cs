﻿// Models/ViewModels/ClaimReviewViewModel.cs
using System.ComponentModel.DataAnnotations;

namespace ContractMonthlyClaimSystem.Models.ViewModels
{
    public class ClaimReviewViewModel
    {
        public int ClaimId { get; set; }
        public string LecturerName { get; set; }
        public decimal HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public decimal TotalAmount { get; set; }
        public string ClaimMonth { get; set; }
        public string Status { get; set; }
        public DateTime SubmittedDate { get; set; }
        public List<ClaimDocument> Documents { get; set; }

        [StringLength(500)]
        public string? Comments { get; set; }

        public string? CoordinatorComments { get; set; }
        public string? ManagerComments { get; set; }
    }
}

