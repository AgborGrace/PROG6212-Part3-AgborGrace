﻿// Models/ViewModels/EditUserViewModel.cs
using System.ComponentModel.DataAnnotations;

namespace ContractMonthlyClaimSystem.Models.ViewModels
{
    public class EditUserViewModel
    {
        public int UserId { get; set; }

        [Required]
        [StringLength(100)]
        public string FirstName { get; set; }

        [Required]
        [StringLength(100)]
        public string LastName { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Role { get; set; }

        [Range(0, 999999)]
        public decimal? HourlyRate { get; set; }

        public bool IsActive { get; set; }

        [DataType(DataType.Password)]
        public string? NewPassword { get; set; }
    }
}
