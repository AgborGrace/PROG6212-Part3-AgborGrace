﻿// File: Models/ErrorViewModel.cs
using System;

namespace ContractMonthlyClaimSystem.Models
{
    public class ErrorViewModel
    {
        // Matches the default ASP.NET template ErrorViewModel
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}

