﻿// Models/ViewModels/ReportViewModel.cs
namespace ContractMonthlyClaimSystem.Models.ViewModels
{
    public class ReportViewModel
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? Status { get; set; }
        public int? LecturerId { get; set; }
        public List<Claim> Claims { get; set; }
        public List<User> Lecturers { get; set; }
    }
}
