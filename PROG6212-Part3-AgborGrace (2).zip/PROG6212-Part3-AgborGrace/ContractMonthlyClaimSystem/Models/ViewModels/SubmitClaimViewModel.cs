﻿// Models/ViewModels/SubmitClaimViewModel.cs
using System.ComponentModel.DataAnnotations;

namespace ContractMonthlyClaimSystem.Models.ViewModels
{
    public class SubmitClaimViewModel
    {
        [Required(ErrorMessage = "Hours worked is required")]
        [Range(0.01, 180, ErrorMessage = "Hours must be between 0.01 and 180")]
        public decimal HoursWorked { get; set; }

        [Required(ErrorMessage = "Claim month is required")]
        public string ClaimMonth { get; set; }

        [Required(ErrorMessage = "Please upload at least one supporting document")]
        public List<IFormFile> Documents { get; set; }

        // Read-only properties populated from user data
        public string LecturerName { get; set; }
        public decimal HourlyRate { get; set; }
        public decimal TotalAmount { get; set; }
    }
}
